g++ -std=c++11 -O3 -w -Iinclude/ src/main.cpp -o obj/main.o
g++ -std=c++11 -O3 -w -Iinclude/ src/plot.cpp -o obj/plot.o



