git clone https://github.com/SociallyAwake/COL761-Data-Mining
