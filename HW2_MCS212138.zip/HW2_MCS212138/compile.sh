make clean
make all