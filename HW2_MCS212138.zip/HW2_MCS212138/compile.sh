module load compiler/gcc/11.2.0
module load compiler/python/3.6.0/ucs4/gnu/447
module load pythonpackages/3.6.0/scikit-learn/0.21.2/gnu
make clean
make all